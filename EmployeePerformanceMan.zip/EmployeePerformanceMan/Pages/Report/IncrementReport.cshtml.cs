﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Report
{
    public class IncrementReportModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public IncrementReportModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        public List<EmpSalarycomp> EmpSalarycomp;

        public async Task OnGetAsync()
        {
            EmpSalarycomp = new List<EmpSalarycomp>();
            EmpSalarycomp empInc;
            foreach (var emp in await _context.Employee.ToListAsync())
            {
                empInc = new EmpSalarycomp();
                empInc.emp_code = emp.emp_code;
                empInc.name = emp.name;
                empInc.dob = emp.dob;
                empInc.age = DateTime.Today.Year - emp.dob.Year;
                empInc.grade = _context.Grade.SingleOrDefault(x => x.id == emp.grade_id).grade;
                empInc.rating = _context.Rating.SingleOrDefault(x => x.id == emp.rating_id).rating;
                decimal percentage = 0;
                if (_context.IncrementMatrix.SingleOrDefault(x => x.grade_id == emp.grade_id && x.rating_id == emp.rating_id)!=null && _context.IncrementMatrix.SingleOrDefault(x => x.grade_id == emp.grade_id && x.rating_id == emp.rating_id).percentage!=null)
                {
                    percentage = _context.IncrementMatrix.SingleOrDefault(x => x.grade_id == emp.grade_id && x.rating_id == emp.rating_id).percentage;
                }               
                empInc.increment = percentage ;
                empInc.currenttotalpay = emp.basic + emp.hra + emp.conv;
                decimal incrementAmt = (empInc.currenttotalpay * empInc.increment) / 100;
                empInc.incrementtotalpay = empInc.currenttotalpay + incrementAmt;
                empInc.totalincrement = incrementAmt;
                EmpSalarycomp.Add(empInc);
            }
            
        }
    }
}
