﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;
using System.IO;

namespace EmployeePerformanceMan.Pages.Masters.EmployeeMaster
{
    public class IndexModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public IndexModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        public IList<Employee> Employee { get;set; }
        public List<EmployeeViewModel> EmployeeViewModelM;
        public string path;
        public async Task OnGetAsync()
        {
             path = Directory.GetCurrentDirectory();
              
            EmployeeViewModelM = new List<EmployeeViewModel>();
            foreach (var item2 in await _context.Employee.ToListAsync())
            {
                EmployeeViewModel item = new EmployeeViewModel();
                item.EmployeeM = item2;
                item.grade = _context.Grade.SingleOrDefault(x => x.id == item2.grade_id).grade;
                item.rating = _context.Rating.SingleOrDefault(x => x.id == item2.rating_id).rating;
                item.basic = Convert.ToString(item2.basic);
                item.hra = Convert.ToString(item2.hra);
                item.conv = Convert.ToString(item2.conv);
                EmployeeViewModelM.Add(item);
            }
        }
    }
}
