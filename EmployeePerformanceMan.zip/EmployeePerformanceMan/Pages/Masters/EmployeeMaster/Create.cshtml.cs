﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using EmployeePerformanceMan.Pages.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using System.IO;

namespace EmployeePerformanceMan.Pages.Masters.EmployeeMaster
{
    public class CreateModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;
        private IHostingEnvironment _environment;
        public CreateModel(EmployeePerformanceMan.Pages.Model.PMContext context, IHostingEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }
        public List<SelectListItem> OptionsGr { get; set; }
        public List<SelectListItem> OptionsRating { get; set; }
        public int grade_id { get; set; }
        public int rating_id { get; set; }
        public IActionResult OnGet()
        {
            OptionsGr = _context.Grade.ToList().Select(a =>
                               new SelectListItem
                               {
                                   Value = a.id.ToString(),
                                   Text = a.grade
                               }).ToList();

            OptionsRating = _context.Rating.ToList().Select(a =>
                               new SelectListItem
                               {
                                   Value = a.id.ToString(),
                                   Text = a.rating.ToString()
                               }).ToList();
            return Page();
        }

        [BindProperty]
        public Employee Employee { get; set; }
        public IFormFile Upload { get; set; }
      

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            var file = Path.Combine(_environment.ContentRootPath, "upload", Employee.emp_code.ToString()+""+".jpg");
            using (var fileStream = new FileStream(file, FileMode.Create))
            {
                await Upload.CopyToAsync(fileStream);
            }
                      
            Employee.photo = Path.GetFileName(file);
            Employee.grade_id = Convert.ToInt32(Request.Form["grade_id"]);
            Employee.rating_id = Convert.ToInt32(Request.Form["rating_id"]);
            _context.Employee.Add(Employee);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
