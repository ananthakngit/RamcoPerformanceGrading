﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;
using System.ComponentModel.DataAnnotations;

namespace EmployeePerformanceMan.Pages.Masters.RatingMaster
{
    public class DeleteModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public DeleteModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Rating Rating { get; set; }
        public string Mssg { get; set; }
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Rating = await _context.Rating.FirstOrDefaultAsync(m => m.id == id);

            if (Rating == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
           
            Rating = await _context.Rating.FindAsync(id);

            if (Rating != null)
            {
                Mssg = "";
                if (_context.IncrementMatrix.Count(x => x.rating_id == id) == 0)
                {
                    _context.Rating.Remove(Rating);
                    await _context.SaveChangesAsync();
                }
                else
                {

                    Mssg=  "Sorry, Rating already mapped with employee";
                    return Page();
                }
            }

            return RedirectToPage("./Index");
        }
    }
}
