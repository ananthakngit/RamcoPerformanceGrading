﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Masters.IncrementMatrixMaster1
{
    public class DeleteModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public DeleteModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        [BindProperty]
        public IncrementMatrix IncrementMatrix { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            IncrementMatrix = await _context.IncrementMatrix.FirstOrDefaultAsync(m => m.id == id);

            if (IncrementMatrix == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            IncrementMatrix = await _context.IncrementMatrix.FindAsync(id);

            if (IncrementMatrix != null)
            {
                _context.IncrementMatrix.Remove(IncrementMatrix);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
