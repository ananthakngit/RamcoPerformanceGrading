﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Masters.IncrementMatrixMaster
{
    public class CreateModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public CreateModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        public List<SelectListItem> OptionsGr { get; set; }
        public List<SelectListItem> OptionsRating { get; set; }
        public int grade_id { get; set; }
        public int rating_id { get; set; }
        public IActionResult OnGet()
        {
            OptionsGr = _context.Grade.ToList().Select(a =>
                                 new SelectListItem
                                 {
                                     Value = a.id.ToString(),
                                     Text = a.grade
                                 }).ToList();

            OptionsRating = _context.Rating.ToList().Select(a =>
                               new SelectListItem
                               {
                                   Value = a.id.ToString(),
                                   Text = a.rating.ToString()
                               }).ToList();

            return Page();
        }

        [BindProperty]
        public IncrementMatrix IncrementMatrix { get; set; }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            IncrementMatrix.grade_id=Convert.ToInt32( Request.Form["grade_id"]);
            IncrementMatrix.rating_id = Convert.ToInt32(Request.Form["rating_id"]);
            _context.IncrementMatrix.Add(IncrementMatrix);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
