﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Masters.IncrementMatrixMaster1
{
    public class EditModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public EditModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        [BindProperty]
        public IncrementMatrix IncrementMatrix { get; set; }

        public List<SelectListItem> OptionsGr { get; set; }
        public List<SelectListItem> OptionsRating { get; set; }
        public int grade_id { get; set; }
        public int rating_id { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            IncrementMatrix = await _context.IncrementMatrix.FirstOrDefaultAsync(m => m.id == id);

            if (IncrementMatrix == null)
            {
                return NotFound();
            }

            OptionsGr = _context.Grade.ToList().Select(a =>
                                new SelectListItem
                                {
                                    Value = a.id.ToString(),
                                    Text = a.grade
                                }).ToList();

            OptionsRating = _context.Rating.ToList().Select(a =>
                               new SelectListItem
                               {
                                   Value = a.id.ToString(),
                                   Text = a.rating.ToString()
                               }).ToList();


            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            IncrementMatrix.grade_id = Convert.ToInt32(Request.Form["grade_id"]);
            IncrementMatrix.rating_id = Convert.ToInt32(Request.Form["rating_id"]);
            _context.Attach(IncrementMatrix).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!IncrementMatrixExists(IncrementMatrix.id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool IncrementMatrixExists(int id)
        {
            return _context.IncrementMatrix.Any(e => e.id == id);
        }
    }
}
