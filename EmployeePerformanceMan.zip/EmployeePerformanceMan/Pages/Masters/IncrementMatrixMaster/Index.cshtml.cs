﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Masters.IncrementMatrixMaster1
{
    public class IndexModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public IndexModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        public List<IncrementMatrixViewModel> IncrementMatrixVM;

        public async Task OnGetAsync()
        {
            IncrementMatrixVM = new List<IncrementMatrixViewModel>();
              foreach (var item2 in _context.IncrementMatrix.ToList())
                {
                   IncrementMatrixViewModel item = new IncrementMatrixViewModel();
                    item.IncrementMatrixM = item2;
                    item.grade = _context.Grade.SingleOrDefault(x => x.id == item2.grade_id)!=null? _context.Grade.SingleOrDefault(x => x.id == item2.grade_id).grade:"";
                    item.rating = _context.Rating.SingleOrDefault(x => x.id == item2.rating_id)!=null?_context.Rating.SingleOrDefault(x => x.id == item2.rating_id).rating:0;                    
                    IncrementMatrixVM.Add(item);
                }
            

            //IncrementMatrixM =  IncrementMatrixVM.ToList();
        }
    }
}
