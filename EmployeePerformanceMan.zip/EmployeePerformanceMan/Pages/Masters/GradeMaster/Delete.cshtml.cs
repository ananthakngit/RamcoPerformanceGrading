﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Masters.GradeMaster
{
    public class DeleteModel : PageModel
    {
        private readonly EmployeePerformanceMan.Pages.Model.PMContext _context;

        public DeleteModel(EmployeePerformanceMan.Pages.Model.PMContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Grade Grade { get; set; }
        public string Mssg { get; set; }
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Grade = await _context.Grade.FirstOrDefaultAsync(m => m.id == id);

            if (Grade == null)
            {
                return NotFound();
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Grade = await _context.Grade.FindAsync(id);

            if (Grade != null)
            {
                Mssg = "";
                if (_context.IncrementMatrix.Count(x => x.grade_id == id) == 0)
                {
                    _context.Grade.Remove(Grade);
                    await _context.SaveChangesAsync();
                }
                else
                {

                    Mssg = "Sorry, Grade already mapped with employee";
                    return Page();
                }
            }

            return RedirectToPage("./Index");
        }
    }
}
