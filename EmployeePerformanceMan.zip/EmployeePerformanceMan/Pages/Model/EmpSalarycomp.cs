﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeePerformanceMan.Pages.Model
{
    public class EmpSalarycomp
    {
        [Required]
        [Key]
        public int id { get; set; }

        [Required]
        public int emp_code { get; set; }

        [Required]
        public string name { get; set; }

        [Required]
        public DateTime dob { get; set; }
        
        [Required]
        public int age { get; set; }

        [Required]
        public string grade { get; set; }

        [Required]
        public int rating { get; set; }

        [Required]
        public decimal increment { get; set; }

        [Required]
        public decimal currenttotalpay { get; set; }

        [Required]
        public decimal incrementtotalpay { get; set; }
      
        public decimal totalincrement { get; set; }

    }
}
