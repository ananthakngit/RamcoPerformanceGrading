﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeePerformanceMan.Pages.Model
{
    public class EmployeeViewModel
    {
        [Required]
        public Employee EmployeeM { get; set; }

        [Required]
        public string grade { get; set; }

        [Required]
        public int rating { get; set; }

        [Required]
        public string basic { get; set; }

        [Required]
        public string hra { get; set; }

        [Required]
        public string conv { get; set; }

    }
}
