﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeePerformanceMan.Pages.Model
{
    public class IncrementMatrixViewModel
    {
        [Required]        
        public  IncrementMatrix IncrementMatrixM { get; set; }

        [Required]
        public string grade { get; set; }

        [Required]
        public int rating { get; set; }        
        
    }
}
