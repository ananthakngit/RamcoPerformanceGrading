﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeePerformanceMan.Pages.Model
{
    public class IncrementMatrix
    {
        [Required]
        [Key]
        public int id { get; set; }

        [Required]
        public int grade_id { get; set; }

        [Required]
        public int rating_id { get; set; }

        [Required]
        public decimal percentage { get; set; }

        
    }
}
