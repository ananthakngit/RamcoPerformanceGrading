﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EmployeePerformanceMan.Pages.Model;

namespace EmployeePerformanceMan.Pages.Model
{
    public class PMContext: DbContext
    {
        public PMContext(DbContextOptions<PMContext> options) : base(options) { }

        public DbSet<Grade> Grade { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Grade>(entity =>
            {
                entity.Property(e => e.id)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.grade)
                    .IsRequired()
                    .HasMaxLength(250)
                    .IsUnicode(false);
               
            });
        }

        public DbSet<EmployeePerformanceMan.Pages.Model.Employee> Employee { get; set; }

        public DbSet<EmployeePerformanceMan.Pages.Model.Rating> Rating { get; set; }

        public DbSet<EmployeePerformanceMan.Pages.Model.IncrementMatrix> IncrementMatrix { get; set; }

        public DbSet<EmployeePerformanceMan.Pages.Model.EmpSalarycomp> EmpSalarycomp { get; set; }

    }
}
