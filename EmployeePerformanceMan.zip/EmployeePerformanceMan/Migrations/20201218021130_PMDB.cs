﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EmployeePerformanceMan.Migrations
{
    public partial class PMDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Grademodel",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", unicode: false, maxLength: 50, nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    grade = table.Column<int>(type: "int", unicode: false, maxLength: 250, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Grademodel", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Grademodel");
        }
    }
}
